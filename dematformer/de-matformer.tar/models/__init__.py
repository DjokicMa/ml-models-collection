"""Graph neural network implementations."""
